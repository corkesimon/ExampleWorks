package main;
/**
 * Interface for a decision tree
 * */
public interface DT {

	public void report(String string);
	

}

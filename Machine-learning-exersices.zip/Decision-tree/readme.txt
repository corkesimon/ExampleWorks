parameters for running the program are:

training-data test-data
parameters for the program are:

images-filename
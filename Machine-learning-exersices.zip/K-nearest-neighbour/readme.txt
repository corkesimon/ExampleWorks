Program takes 3 parameters
training -data test-data k